import { AfterViewInit, Component, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { gsap } from 'gsap';

type ProductType = 'boundary-wall' | 'barbed-fencing' | 'manual';
type MeasurementType = 'area' | 'perimeter';
type ManualType = 'boundary' | 'fencing';

interface QuoteField {
  id: number;
  measurementType: MeasurementType;
  displayText: string;
  biswa?: number;
  perimeterFeet?: number;
}

interface QuoteExpense {
  id: number;
  name: string;
  description: string;
  amount: number;
}

interface BreakdownLine {
  label: string;
  value: string;
}

interface QuoteResult {
  productName: string;
  totalArea: number;
  perimeterFeet: number;
  perimeterMeters: number;
  wallHeight?: number;
  wallArea?: number;
  poles?: number;
  wireWeight?: number;
  labourDays?: number;
  lines: BreakdownLine[];
  total: number;
}

@Component({
  selector: 'qc-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App implements AfterViewInit, OnDestroy {
  readonly biswaToSqFt = 1350;
  readonly boundaryWallRate = 85;
  readonly poleRate = 300;
  readonly poleDistance = 10;
  readonly wirePerSegmentKg = 1;
  readonly wireRate = 105;
  readonly labourRatePerDay = 500;
  readonly wallHeights = [4, 5, 6, 7, 8, 9, 10];

  productType: ProductType = 'boundary-wall';
  measurementType: MeasurementType = 'area';
  manualType: ManualType = 'boundary';
  areaBiswa = 1;
  customPerimeter: number | null = null;
  wallHeight = 6;

  manualBoundaryRate = this.boundaryWallRate;
  manualWallLabour = 0;
  manualPoles = 0;
  manualPoleRate = this.poleRate;
  manualWireWeight = 0;
  manualWireCost = 0;
  manualFencingLabour = 0;

  fields: QuoteField[] = [];
  expenses: QuoteExpense[] = [];
  showExpenseForm = false;
  expenseName = '';
  expenseDescription = '';
  expenseAmount: number | null = null;
  message = '';
  result: QuoteResult | null = null;
  private nextFieldId = 1;
  private nextExpenseId = 1;
  private animationContext?: gsap.Context;

  ngAfterViewInit(): void {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      return;
    }

    this.animationContext = gsap.context(() => {
      gsap.from('.animate-in', {
        y: 16,
        opacity: 0,
        duration: 0.65,
        stagger: 0.08,
        ease: 'power2.out'
      });
    });
  }

  ngOnDestroy(): void {
    this.animationContext?.revert();
  }

  chooseProduct(type: ProductType): void {
    this.productType = type;
    this.result = null;
    this.message = '';
  }

  chooseMeasurement(type: MeasurementType): void {
    this.measurementType = type;
    this.message = '';
  }

  addField(): void {
    if (this.measurementType === 'area') {
      const biswa = Number(this.areaBiswa);
      if (!Number.isFinite(biswa) || biswa <= 0) {
        this.message = 'Enter a land area greater than zero.';
        return;
      }
      this.fields.push({
        id: this.nextFieldId++,
        measurementType: 'area',
        biswa,
        displayText: `${biswa.toLocaleString('en-IN')} ${biswa === 1 ? 'Biswa' : 'Biswa'}`
      });
    } else {
      const perimeter = Number(this.customPerimeter);
      if (!Number.isFinite(perimeter) || perimeter <= 0) {
        this.message = 'Enter running feet greater than zero.';
        return;
      }
      this.fields.push({
        id: this.nextFieldId++,
        measurementType: 'perimeter',
        perimeterFeet: perimeter,
        displayText: `${perimeter.toLocaleString('en-IN')} running ft`
      });
      this.customPerimeter = null;
    }

    this.result = null;
    this.message = '';
  }

  removeField(id: number): void {
    this.fields = this.fields.filter((field) => field.id !== id);
    this.result = null;
  }

  setManualType(type: ManualType): void {
    this.manualType = type;
    this.result = null;
  }

  addExpense(): void {
    const name = this.expenseName.trim();
    const amount = Number(this.expenseAmount);
    if (!name || !Number.isFinite(amount) || amount <= 0) {
      this.message = 'Enter an expense name and an amount greater than zero.';
      return;
    }

    this.expenses.push({
      id: this.nextExpenseId++,
      name,
      description: this.expenseDescription.trim(),
      amount
    });
    this.expenseName = '';
    this.expenseDescription = '';
    this.expenseAmount = null;
    this.showExpenseForm = false;
    this.message = '';
    this.recalculateIfShown();
  }

  removeExpense(id: number): void {
    this.expenses = this.expenses.filter((expense) => expense.id !== id);
    this.recalculateIfShown();
  }

  get totalBiswa(): number {
    return this.fields.reduce((total, field) => total + (field.biswa ?? 0), 0);
  }

  get totalArea(): number {
    return Math.round(this.totalBiswa * this.biswaToSqFt);
  }

  get totalPerimeter(): number {
    return this.fields.reduce((total, field) => {
      if (field.measurementType === 'perimeter') {
        return total + (field.perimeterFeet ?? 0);
      }
      const area = (field.biswa ?? 0) * this.biswaToSqFt;
      return total + 4 * Math.sqrt(area);
    }, 0);
  }

  calculate(): void {
    if (this.fields.length === 0) {
      this.message = 'Add at least one land measurement to calculate a quotation.';
      this.result = null;
      return;
    }

    const perimeterFeet = this.totalPerimeter;
    const totalArea = this.totalArea;
    const perimeterMeters = Math.round(perimeterFeet * 0.3048 * 10) / 10;
    const expenseTotal = this.expenses.reduce((sum, expense) => sum + expense.amount, 0);
    let productName = '';
    let total = 0;
    let wallArea: number | undefined;
    let poles: number | undefined;
    let wireWeight: number | undefined;
    let labourDays: number | undefined;
    let lines: BreakdownLine[] = [
      { label: 'Measurements included', value: String(this.fields.length) },
      { label: 'Total land area', value: `${totalArea.toLocaleString('en-IN')} sq ft` },
      { label: 'Total perimeter', value: `${Math.round(perimeterFeet).toLocaleString('en-IN')} ft (${perimeterMeters} m)` }
    ];

    if (this.productType === 'boundary-wall' ||
        (this.productType === 'manual' && this.manualType === 'boundary')) {
      productName = 'Precast Boundary Wall';
      const rate = this.productType === 'manual'
        ? this.nonNegative(this.manualBoundaryRate)
        : this.boundaryWallRate;
      wallArea = Math.round(perimeterFeet * this.wallHeight);
      const wallCost = Math.round(wallArea * rate);
      const labourCost = this.productType === 'manual' ? this.nonNegative(this.manualWallLabour) : 0;
      total = wallCost + labourCost + expenseTotal;
      lines = [
        ...lines,
        { label: `Wall area (${this.wallHeight} ft high)`, value: `${wallArea.toLocaleString('en-IN')} sq ft` },
        { label: 'All-inclusive wall rate', value: `${this.formatCurrency(rate)} / sq ft` },
        { label: 'Wall work', value: this.formatCurrency(wallCost) }
      ];
      if (this.productType === 'manual') {
        lines.push({ label: 'Labour', value: this.formatCurrency(labourCost) });
      } else {
        lines.push({ label: 'Installation', value: 'Included in rate' });
      }
    } else {
      productName = 'Barbed Wire Fencing';
      const manual = this.productType === 'manual';
      poles = manual
        ? Math.floor(this.nonNegative(this.manualPoles))
        : Math.ceil(perimeterFeet / this.poleDistance) + this.fields.length;
      const ratePerPole = manual ? this.nonNegative(this.manualPoleRate) : this.poleRate;
      const poleCost = poles * ratePerPole;
      wireWeight = manual
        ? this.nonNegative(this.manualWireWeight)
        : Math.ceil(perimeterFeet / this.poleDistance) * this.wirePerSegmentKg;
      const wireCost = manual ? this.nonNegative(this.manualWireCost) : Math.round(wireWeight * this.wireRate);
      labourDays = manual ? undefined : Math.ceil(perimeterFeet / 100);
      const labourCost = manual ? this.nonNegative(this.manualFencingLabour) : (labourDays ?? 0) * this.labourRatePerDay;
      total = poleCost + wireCost + labourCost + expenseTotal;
      lines = [
        ...lines,
        { label: 'Fence poles', value: `${poles.toLocaleString('en-IN')} × ${this.formatCurrency(ratePerPole)}` },
        { label: 'Pole cost', value: this.formatCurrency(poleCost) },
        { label: 'Barbed wire', value: `${wireWeight.toLocaleString('en-IN')} kg · ${this.formatCurrency(wireCost)}` }
      ];
      if (manual) {
        lines.push({ label: 'Labour & installation', value: this.formatCurrency(labourCost) });
      } else {
        lines.push({ label: `Labour (${labourDays} ${labourDays === 1 ? 'day' : 'days'})`, value: this.formatCurrency(labourCost) });
      }
    }

    if (this.expenses.length) {
      lines.push(...this.expenses.map((expense) => ({
        label: expense.name,
        value: this.formatCurrency(expense.amount)
      })));
    }

    this.result = {
      productName,
      totalArea,
      perimeterFeet: Math.round(perimeterFeet),
      perimeterMeters,
      wallHeight: wallArea === undefined ? undefined : this.wallHeight,
      wallArea,
      poles,
      wireWeight,
      labourDays,
      lines,
      total: Math.round(total)
    };
    this.message = '';
  }

  reset(): void {
    this.productType = 'boundary-wall';
    this.measurementType = 'area';
    this.manualType = 'boundary';
    this.areaBiswa = 1;
    this.customPerimeter = null;
    this.wallHeight = 6;
    this.manualBoundaryRate = this.boundaryWallRate;
    this.manualWallLabour = 0;
    this.manualPoles = 0;
    this.manualPoleRate = this.poleRate;
    this.manualWireWeight = 0;
    this.manualWireCost = 0;
    this.manualFencingLabour = 0;
    this.fields = [];
    this.expenses = [];
    this.result = null;
    this.message = '';
  }

  shareOnWhatsApp(): void {
    if (!this.result) {
      return;
    }
    const text = [
      `Quotation estimate · ${this.result.productName}`,
      `Total: ${this.formatCurrency(this.result.total)}`,
      `Perimeter: ${this.result.perimeterFeet} ft (${this.result.perimeterMeters} m)`,
      ...this.result.lines.map((line) => `${line.label}: ${line.value}`),
      '',
      'This is an estimate; final pricing is subject to site verification.'
    ].join('\n');
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank', 'noopener,noreferrer');
  }

  printQuote(): void {
    if (this.result) {
      window.print();
    }
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  }

  private nonNegative(value: number | null | undefined): number {
    const number = Number(value);
    return Number.isFinite(number) ? Math.max(0, number) : 0;
  }

  private recalculateIfShown(): void {
    if (this.result) {
      this.calculate();
    }
  }
}
